#HLS/HTTP/Secure/Plex/Int/Compact/TS/White/Good/Remote/Movies/Multilink/Modified/Robust/Favs/Adaptive
import sys,urllib.request,urllib.parse,urllib.error,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,re,time,json,os,base64,xml.etree.ElementTree as ET,hashlib,socket,ssl
from datetime import datetime,timedelta
from urllib.error import URLError
from http.client import IncompleteRead
try: 
    import inputstreamhelper
    HAS_INPUTSTREAM_HELPER = True
except: 
    HAS_INPUTSTREAM_HELPER = False

# ResolveURL imports
try:
    from resolveurl import resolve
    from resolveurl import display_settings
    HAS_RESOLVEURL = True
except:
    HAS_RESOLVEURL = False

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.vortex"
HANDLE = int(sys.argv[1])
TOKEN_CACHE_DIR = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/tokens/")
TOKEN_CACHE_FILE = os.path.join(TOKEN_CACHE_DIR, "token_cache.json")

# Remote configuration URL
CONFIG_URL = "https://raw.githubusercontent.com/vortex-repo/101/refs/heads/main/config.json"

# Global config variables (loaded from remote)
PLAYLIST_SOURCES = {}
BLOCKED_KEYWORDS = []
TITLE_BLOCK_PATTERNS = []
CACHE_DURATION = 12 * 60 * 60
MOVIE_CACHE_DURATION = 6 * 60 * 60
MAX_TITLE_LENGTH = 40
TOKEN_VALIDITY = 3600

# Default inputstream settings - MANUAL BANDWIDTH CONTROL (auto-detection disabled)
DEFAULT_STREAM_SETTINGS = {
    'live_delay': '10',
    'live_seekable': 'true',
    'live_playlist_retry_attempts': '10',
    'live_playlist_retry_delay': '3000',
    'live_playlist_readahead': '5',
    'bandwidth_factor': '1.0',  # Set to 1.0 to disable auto-detection behavior
    'max_bandwidth': '10000000',
    'media_bandwidth': '5000000',
    'manifest_retry_attempts': '5',
    'manifest_retry_delay': '2000',
    'timeout': '30',
    'connection_retry': '5',
    'session_reconnect': 'true',
    'adaptive_debug': 'false',
    # Force manual bandwidth control
    'use_manual_bandwidth': 'true',
    'auto_bandwidth': 'false'
}

# Circuit breaker for problematic streams
class StreamCircuitBreaker:
    """Prevents repeated attempts to play failing streams"""
    def __init__(self, max_failures=3, reset_timeout=300):
        self.failures = {}
        self.max_failures = max_failures
        self.reset_timeout = reset_timeout
    
    def check_url(self, url):
        key = hashlib.md5(url.encode()).hexdigest()
        if key in self.failures:
            failure_data = self.failures[key]
            if failure_data['count'] >= self.max_failures:
                if time.time() - failure_data['last_attempt'] < self.reset_timeout:
                    log(f"Circuit breaker tripped for {url[:50]}...", xbmc.LOGWARNING)
                    return False
                else:
                    # Reset after timeout
                    del self.failures[key]
        return True
    
    def record_failure(self, url):
        key = hashlib.md5(url.encode()).hexdigest()
        if key not in self.failures:
            self.failures[key] = {'count': 0, 'last_attempt': 0}
        self.failures[key]['count'] += 1
        self.failures[key]['last_attempt'] = time.time()

# Initialize circuit breaker
circuit_breaker = StreamCircuitBreaker()

def verify_addon_id():
    try: 
        return ET.parse(os.path.join(ADDON_PATH,'addon.xml')).getroot().get('id','') == ADDON_ID
    except: 
        return False
if not verify_addon_id(): 
    sys.exit()

ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")
CACHE_DIR = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/")
CACHE_FILE = os.path.join(CACHE_DIR, "playlist_cache.dat")
MOVIE_CACHE_FILE = os.path.join(CACHE_DIR, "movie_cache.dat")
FAVOURITES_FILE = os.path.join(CACHE_DIR, "encrypted_favourites.dat")
SETTINGS_FILE = os.path.join(CACHE_DIR, "stream_settings.json")
XOR_KEY = b"k5F9#mR2@qW8!zX0$vB7%nC1^aD3&sE4*lG6(jH0)pK9_yL2"

seen_titles_global = set()

def fetch_remote_config():
    """Fetch configuration from remote JSON file"""
    global PLAYLIST_SOURCES, BLOCKED_KEYWORDS, TITLE_BLOCK_PATTERNS, CACHE_DURATION, MOVIE_CACHE_DURATION, MAX_TITLE_LENGTH, TOKEN_VALIDITY
    
    try:
        req = urllib.request.Request(CONFIG_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                config = json.loads(response.read().decode('utf-8'))
                
                # Load playlist sources
                PLAYLIST_SOURCES = config.get('playlist_sources', {})
                
                # Load blocked keywords
                BLOCKED_KEYWORDS = config.get('blocked_keywords', [])
                
                # Load title block patterns
                TITLE_BLOCK_PATTERNS = config.get('title_block_patterns', [])
                
                # Load cache settings
                CACHE_DURATION = config.get('cache_duration', 12 * 60 * 60)
                MOVIE_CACHE_DURATION = config.get('movie_cache_duration', 6 * 60 * 60)
                MAX_TITLE_LENGTH = config.get('max_title_length', 40)
                TOKEN_VALIDITY = config.get('token_validity', 3600)
                
                log(f"Config loaded successfully: {len(PLAYLIST_SOURCES)} sources, {len(BLOCKED_KEYWORDS)} blocked keywords")
                return True
            else:
                log(f"Failed to load config: HTTP {response.status}", xbmc.LOGERROR)
                return False
    except Exception as e:
        log(f"Error loading remote config: {str(e)}", xbmc.LOGERROR)
        return False

def log(message, level=xbmc.LOGINFO): 
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def ensure_token_cache_dir():
    if not xbmcvfs.exists(TOKEN_CACHE_DIR): 
        xbmcvfs.mkdirs(TOKEN_CACHE_DIR)

def load_token_cache():
    ensure_token_cache_dir()
    if not xbmcvfs.exists(TOKEN_CACHE_FILE): 
        return {}
    try:
        with open(TOKEN_CACHE_FILE,'r') as f: 
            return json.load(f)
    except Exception as e: 
        log(f"Error loading token cache: {str(e)}", xbmc.LOGWARNING)
        return {}

def save_token_cache(token_data):
    try:
        ensure_token_cache_dir()
        with open(TOKEN_CACHE_FILE,'w') as f: 
            json.dump(token_data,f)
    except Exception as e: 
        log(f"Error saving token cache: {str(e)}", xbmc.LOGWARNING)

def get_cached_token(channel_id):
    token_cache = load_token_cache()
    if channel_id in token_cache and time.time()-token_cache[channel_id].get('timestamp',0) < token_cache[channel_id].get('validity',TOKEN_VALIDITY): 
        return token_cache[channel_id].get('token')
    return None

def cache_token(channel_id, token, validity=TOKEN_VALIDITY):
    token_cache = load_token_cache()
    token_cache[channel_id] = {'token':token,'timestamp':time.time(),'validity':validity}
    save_token_cache(token_cache)

def extract_channel_id_from_url(url):
    try:
        m=re.search(r'/parts/([a-f0-9]{24})-',url)
        if m: 
            return m.group(1)
        m=re.search(r'/(\d+)/',url)
        if m: 
            return f"channel_{m.group(1)}"
        return hashlib.md5(url.encode()).hexdigest()[:16]
    except: 
        return "unknown"

def extract_token_from_url(url):
    try:
        p=urllib.parse.urlparse(url)
        params=urllib.parse.parse_qs(p.query)
        return params['X-Plex-Token'][0] if 'X-Plex-Token' in params else None
    except: 
        return None

def ensure_cache_dir():
    if not xbmcvfs.exists(CACHE_DIR): 
        xbmcvfs.mkdirs(CACHE_DIR)

def xor_encrypt_decrypt(data):
    if XOR_KEY is None: 
        log("XOR_KEY not initialized!", xbmc.LOGERROR)
        return data
    return bytes([data[i] ^ XOR_KEY[i % len(XOR_KEY)] for i in range(len(data))])

def encrypt_favourite_url(url):
    return base64.b64encode(xor_encrypt_decrypt(url.encode('utf-8'))).decode('utf-8')

def decrypt_favourite_url(encrypted_url):
    try: 
        return xor_encrypt_decrypt(base64.b64decode(encrypted_url.encode('utf-8'))).decode('utf-8')
    except Exception as e: 
        log(f"Error decrypting favourite URL: {str(e)}", xbmc.LOGERROR)
        return None

def load_cache():
    ensure_cache_dir()
    if not xbmcvfs.exists(CACHE_FILE): 
        return {}
    try:
        with open(CACHE_FILE,'rb') as f: 
            encrypted_data=f.read()
        if not encrypted_data: 
            return {}
        cache_data=json.loads(xor_encrypt_decrypt(encrypted_data).decode('utf-8'))
        current_time=time.time()
        cleaned={}
        for s,c in cache_data.items():
            if current_time-c.get('timestamp',0) <= CACHE_DURATION: 
                cleaned[s]=c
        if len(cleaned) != len(cache_data): 
            save_cache(cleaned)
        return cleaned
    except Exception as e: 
        log(f"Error loading cache: {str(e)}", xbmc.LOGERROR)
        return {}

def save_cache(cache_data):
    try:
        ensure_cache_dir()
        with open(CACHE_FILE,'wb') as f: 
            f.write(xor_encrypt_decrypt(json.dumps(cache_data).encode('utf-8')))
    except Exception as e: 
        log(f"Error saving cache: {str(e)}", xbmc.LOGERROR)

def get_cached_channels(source_name):
    if source_name == "Movies":
        return None
    cache=load_cache()
    if source_name in cache and time.time()-cache[source_name].get('timestamp',0) <= CACHE_DURATION: 
        return cache[source_name].get('channels',[])
    return None

def cache_channels(source_name, channels):
    if source_name == "Movies":
        return
    c=load_cache()
    c[source_name]={'timestamp':time.time(),'channels':channels}
    save_cache(c)

def clear_cache():
    f=[]
    if xbmcvfs.exists(CACHE_FILE): 
        xbmcvfs.delete(CACHE_FILE)
        f.append("Playlist cache")
    if xbmcvfs.exists(TOKEN_CACHE_FILE): 
        xbmcvfs.delete(TOKEN_CACHE_FILE)
        f.append("Token cache")
    if xbmcvfs.exists(MOVIE_CACHE_FILE): 
        xbmcvfs.delete(MOVIE_CACHE_FILE)
        f.append("Movie cache")
    return bool(f)

def get_url(**kwargs): 
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def get_encrypted_play_url(url): 
    return get_url(action='play_encrypted', encrypted_url=encrypt_favourite_url(url))

def contains_blocked_keywords(t): 
    return any(k.lower() in (t or '').lower() for k in BLOCKED_KEYWORDS) if t else False

def contains_ascii_characters(t):
    if not t: 
        return False
    try: 
        t.encode('ascii')
        return False
    except: 
        return True

def contains_at_character(t): 
    return '@' in (t or '')

def contains_blocked_patterns(t): 
    return any(re.search(p,(t or '')) for p in TITLE_BLOCK_PATTERNS) if t else False

def exceeds_character_limit(t): 
    return len((t or '').strip()) > MAX_TITLE_LENGTH

def should_skip_channel(t):
    if not t: 
        return True
    if contains_blocked_keywords(t) or contains_ascii_characters(t) or contains_at_character(t) or contains_blocked_patterns(t) or exceeds_character_limit(t): 
        return True
    sp=[r'^\d{1,2}:\d{2}',r'^\d{4}-\d{2}-\d{2}',r'https?://',r'\.(jpg|jpeg|png|gif|bmp|webp)$',r'^\s*$']
    tl=t.lower() if t else ""
    if any(re.search(p,tl) for p in sp): 
        return True
    if len(t.strip()) < 3: 
        return True
    return False

def clean_title(t):
    if not t: 
        return t
    t=re.sub(r'\([^)]*\)','',t)
    t=re.sub(r'\[[^\]]*\]','',t)
    t=re.sub(r'\.(ts|m3u8|mp4|avi|mkv|jpg|jpeg|png|gif)$','',t,flags=re.IGNORECASE)
    t=re.sub(r'\[[^\]]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\]]*?\]','',t,flags=re.IGNORECASE)
    t=re.sub(r'\([^\)]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\)]*?\)','',t,flags=re.IGNORECASE)
    t=re.sub(r'\b(?:HD|SD|FHD|UHD|4K|1080p|720p|480p)\b','',t,flags=re.IGNORECASE)
    return re.sub(r'\s+',' ',t).strip()

def get_stream_headers(url, ah=None):
    h={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'en-US,en;q=0.9','Connection':'keep-alive','Cache-Control':'no-cache','Pragma':'no-cache','DNT':'1'}
    if 'plex.tv' in (url or '').lower():
        h.update({'X-Plex-Client-Identifier':ADDON_ID,'X-Plex-Product':ADDON_NAME,'X-Plex-Version':ADDON_VERSION,'X-Plex-Device':'Kodi','X-Plex-Device-Name':'Kodi Media Player','X-Plex-Platform':'Kodi','X-Plex-Platform-Version':'20.0','Accept-Encoding':'identity','Referer':'https://app.plex.tv/','Origin':'https://app.plex.tv'})
    t=extract_token_from_url(url)
    if t: 
        h['X-Plex-Token']=t
    if ah: 
        h.update(ah)
    return h

# ============ STREAM SETTINGS FUNCTIONS ============

def load_stream_settings():
    """Load user's stream settings from file"""
    if not xbmcvfs.exists(SETTINGS_FILE):
        return DEFAULT_STREAM_SETTINGS.copy()
    try:
        with open(SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
            # Merge with defaults to ensure all keys exist
            for key, value in DEFAULT_STREAM_SETTINGS.items():
                if key not in settings:
                    settings[key] = value
            return settings
    except Exception as e:
        log(f"Error loading stream settings: {str(e)}", xbmc.LOGWARNING)
        return DEFAULT_STREAM_SETTINGS.copy()

def save_stream_settings(settings):
    """Save user's stream settings to file"""
    try:
        ensure_cache_dir()
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(settings, f, indent=2)
        log("Stream settings saved successfully")
        return True
    except Exception as e:
        log(f"Error saving stream settings: {str(e)}", xbmc.LOGERROR)
        return False

def open_inputstream_settings():
    """Open the inputstream.adaptive addon settings"""
    try:
        xbmc.executebuiltin('Addon.OpenSettings(inputstream.adaptive)')
        xbmcgui.Dialog().notification('Stream Settings', 'Opened inputstream.adaptive settings', ADDON_ICON, 3000)
    except Exception as e:
        log(f"Error opening inputstream settings: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', 'Could not open inputstream.adaptive settings.\nMake sure it is installed.')

# ============ ENHANCED PLAYLIST FUNCTIONS ============

# ENHANCED: Fetch playlist content with retry and fallback
def fetch_playlist_content(url, retries=5, timeout=30):
    """Enhanced playlist fetcher with better error handling and fallback"""
    last_error = None
    
    for attempt in range(retries):
        try:
            # Create request with proper headers
            req = urllib.request.Request(url, headers=get_stream_headers(url))
            
            # Add timeout with socket options for better stability
            with urllib.request.urlopen(req, timeout=timeout) as response:
                # Check if response is valid
                if response.status != 200:
                    log(f"HTTP {response.status} on attempt {attempt + 1}", xbmc.LOGWARNING)
                    if attempt < retries - 1:
                        time.sleep(min(2 ** attempt, 30))  # Exponential backoff
                        continue
                    return None
                
                # Read content with chunking for large files
                content = b''
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    content += chunk
                
                # Try to decode with fallback encodings
                try:
                    decoded = content.decode('utf-8')
                except UnicodeDecodeError:
                    try:
                        decoded = content.decode('latin-1')
                    except UnicodeDecodeError:
                        decoded = content.decode('utf-8', errors='ignore')
                
                log(f"Successfully fetched playlist on attempt {attempt + 1} ({len(decoded)} bytes)")
                return decoded
                
        except (URLError, socket.timeout, ConnectionError) as e:
            last_error = e
            log(f"Network error on attempt {attempt + 1}: {str(e)}", xbmc.LOGWARNING)
            
            if attempt < retries - 1:
                wait_time = min(2 ** attempt, 30)
                log(f"Retrying in {wait_time} seconds...", xbmc.LOGDEBUG)
                time.sleep(wait_time)
            else:
                log(f"All {retries} attempts failed: {str(e)}", xbmc.LOGERROR)
                
        except IncompleteRead as e:
            last_error = e
            log(f"Incomplete read on attempt {attempt + 1}: {str(e)}", xbmc.LOGWARNING)
            if attempt < retries - 1:
                time.sleep(1)
            else:
                log("Failed to complete read after all attempts", xbmc.LOGERROR)
                
        except Exception as e:
            last_error = e
            log(f"Unexpected error on attempt {attempt + 1}: {str(e)}", xbmc.LOGERROR)
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
            else:
                log("Failed after all attempts with unexpected error", xbmc.LOGERROR)
    
    return None

# ENHANCED: Parse m3u8 with better error handling
def parse_m3u_playlist(c,sn=""):
    if not c: 
        return []
    ch=[]
    cur={}
    lines=c.split('\n')
    for l in lines:
        l=l.strip()
        if not l or l.startswith('#EXTM3U') or l.startswith('#EXTVLCOPT'): 
            continue
        if l.startswith('#EXTINF:'):
            # Parse extended info with better handling
            try:
                # Extract duration and title
                parts = l.split(',', 1)
                if len(parts) > 1:
                    t=clean_title(parts[1].strip())
                    if should_skip_channel(t): 
                        cur={}
                        continue
                    cur={'title':t,'source':sn}
                else:
                    cur={}
                    continue
            except:
                cur={}
                continue
        elif (l.startswith('http') or l.startswith('https')) and cur:
            cid=extract_channel_id_from_url(l)
            cur['channel_id']=cid
            tok=extract_token_from_url(l)
            if tok and cid: 
                cache_token(cid,tok)
            cur['url']=l
            cur['thumbnail']=ADDON_ICON
            cur['fanart']=ADDON_FANART
            ch.append(cur)
            cur={}
    return ch

def get_channels_from_source(sn,fr=False):
    global seen_titles_global
    
    if sn == "Movies":
        return None
    
    seen_titles_global=set()
    if not fr:
        cc=get_cached_channels(sn)
        if cc is not None: 
            return cc
    if sn not in PLAYLIST_SOURCES: 
        return []
    c=fetch_playlist_content(PLAYLIST_SOURCES[sn])
    if c:
        ch=parse_m3u_playlist(c,sn)
        fc=[]
        for i in ch:
            tl=i['title'].lower()
            if any([contains_blocked_keywords(i['title']),contains_ascii_characters(i['title']),contains_at_character(i['title']),contains_blocked_patterns(i['title']),tl in seen_titles_global]): 
                continue
            seen_titles_global.add(tl)
            fc.append(i)
        cache_channels(sn,fc)
        return fc
    else: 
        cc=get_cached_channels(sn)
        return cc if cc else []

# ============ MOVIE FUNCTIONS ============

def load_movie_cache():
    ensure_cache_dir()
    if not xbmcvfs.exists(MOVIE_CACHE_FILE): 
        return {}
    try:
        with open(MOVIE_CACHE_FILE,'r') as f: 
            return json.load(f)
    except Exception as e: 
        log(f"Error loading movie cache: {str(e)}", xbmc.LOGWARNING)
        return {}

def save_movie_cache(cache_data):
    try:
        ensure_cache_dir()
        with open(MOVIE_CACHE_FILE,'w') as f: 
            json.dump(cache_data,f)
    except Exception as e: 
        log(f"Error saving movie cache: {str(e)}", xbmc.LOGWARNING)

def get_cached_movies():
    cache = load_movie_cache()
    if 'movies' in cache and time.time() - cache['movies'].get('timestamp', 0) <= MOVIE_CACHE_DURATION:
        return cache['movies'].get('list', [])
    return None

def cache_movies(movies):
    cache = load_movie_cache()
    cache['movies'] = {'timestamp': time.time(), 'list': movies}
    save_movie_cache(cache)

def fetch_remote_json(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                data = json.loads(response.read().decode('utf-8'))
                log(f"Successfully fetched JSON from {url}, found {len(data)} items" if isinstance(data, list) else f"Successfully fetched JSON from {url}")
                return data
            else:
                log(f"HTTP {response.status} for movie source {url}", xbmc.LOGWARNING)
                return None
    except Exception as e:
        log(f"Error fetching movie JSON: {str(e)}", xbmc.LOGERROR)
        return None

def resolve_movie_url(url):
    if not HAS_RESOLVEURL:
        log("ResolveURL not available, using direct URL", xbmc.LOGWARNING)
        return url
    
    try:
        resolved_url = resolve(url)
        if resolved_url:
            log(f"Successfully resolved URL: {url[:100]}... -> {resolved_url[:100]}...", xbmc.LOGINFO)
            return resolved_url
        else:
            log(f"Could not resolve URL, using original: {url[:100]}...", xbmc.LOGWARNING)
            return url
    except Exception as e:
        log(f"Error resolving URL: {str(e)}", xbmc.LOGERROR)
        return url

def extract_artwork_url(url, quality='original'):
    if not url:
        return ADDON_ICON
    # Remove trailing dot if present (common issue with TMDB URLs)
    url = url.rstrip('.')
    if 'image.tmdb.org' in url or 'themoviedb.org' in url:
        if quality == 'thumb':
            return re.sub(r'/original/', '/w500/', url)
        elif quality == 'fanart':
            return re.sub(r'/original/', '/w1280/', url)
    return url

def play_movie(url, title="", thumbnail="", fanart=""):
    try:
        log(f"Attempting to play movie: {title} - URL: {url}")
        
        resolved_url = resolve_movie_url(url)
        
        if not resolved_url:
            xbmcgui.Dialog().ok('Playback Error', f'Could not resolve URL for: {title}')
            return False
        
        li = xbmcgui.ListItem(label=title, path=resolved_url)
        li.setProperty('IsPlayable', 'true')
        
        art = {
            'thumb': extract_artwork_url(thumbnail, 'thumb') if thumbnail else ADDON_ICON,
            'icon': extract_artwork_url(thumbnail, 'thumb') if thumbnail else ADDON_ICON,
            'fanart': extract_artwork_url(fanart, 'fanart') if fanart else ADDON_FANART,
            'poster': extract_artwork_url(thumbnail, 'thumb') if thumbnail else ADDON_ICON
        }
        li.setArt(art)
        
        li.setInfo('video', {
            'title': title,
            'plot': f"Playing: {title}"
        })
        
        url_lower = resolved_url.lower()
        if url_lower.endswith('.mp4'):
            li.setMimeType('video/mp4')
        elif url_lower.endswith('.mkv'):
            li.setMimeType('video/x-matroska')
        elif url_lower.endswith('.m3u8'):
            li.setMimeType('application/vnd.apple.mpegurl')
        elif '.mpd' in url_lower:
            li.setMimeType('application/dash+xml')
        else:
            li.setMimeType('video/unknown')
        
        if 'http' in url_lower:
            headers = get_stream_headers(resolved_url)
            if headers:
                header_string = '&'.join([f'{k}={urllib.parse.quote(str(v))}' for k, v in headers.items()])
                li.setPath(f"{resolved_url}|{header_string}")
        
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        return True
        
    except Exception as e:
        log(f"Movie playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Unable to play movie: {str(e)}')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False

def play_movie_with_quality_selector(movie_data, title="", thumbnail="", fanart=""):
    """Show quality/source selector if multiple URLs available, otherwise play directly"""
    urls = movie_data.get('urls', [])
    
    log(f"Movie data received: {movie_data}")
    log(f"URLs found: {urls}")
    
    # If only one URL, play directly without showing selector
    if len(urls) == 1:
        log(f"Single URL found, playing directly: {urls[0]}")
        return play_movie(urls[0], title, thumbnail, fanart)
    
    # Multiple URLs - show selection dialog
    if len(urls) > 1:
        # Create list of choices - simple source numbers
        choices = []
        for idx, url in enumerate(urls):
            # Try to extract quality from URL or just use link number
            quality_label = f"Link {idx + 1}"
            url_lower = url.lower()
            if '1080' in url_lower or '1080p' in url_lower:
                quality_label = "1080p"
            elif '720' in url_lower or '720p' in url_lower:
                quality_label = "720p"
            elif '4k' in url_lower or '2160' in url_lower or '2160p' in url_lower:
                quality_label = "4K"
            elif '480' in url_lower or '480p' in url_lower:
                quality_label = "480p"
            
            choices.append(quality_label)
        
        # Show dialog for user to choose
        dialog = xbmcgui.Dialog()
        selected_idx = dialog.select(f"Select A Link For: {title}", choices)
        
        if selected_idx >= 0:
            selected_url = urls[selected_idx]
            log(f"User selected link {selected_idx + 1}: {selected_url}")
            return play_movie(selected_url, title, thumbnail, fanart)
        else:
            # User cancelled
            log("User cancelled link selection")
            return False
    
    # No URLs found
    log(f"No URLs found for movie: {title}")
    xbmcgui.Dialog().ok('Error', f'No playable links found for: {title}')
    return False

def get_movies(force_refresh=False):
    if not force_refresh:
        cached_movies = get_cached_movies()
        if cached_movies is not None:
            log(f"Returning {len(cached_movies)} cached movies")
            return cached_movies
    
    movie_url = PLAYLIST_SOURCES.get("Movies")
    if not movie_url:
        log("No movie URL found in playlist sources", xbmc.LOGERROR)
        return []
    
    log(f"Fetching movies from: {movie_url}")
    movie_data = fetch_remote_json(movie_url)
    
    if not movie_data:
        log("No movie data received, trying cache", xbmc.LOGWARNING)
        cached_movies = get_cached_movies()
        return cached_movies if cached_movies else []
    
    movies = []
    
    if isinstance(movie_data, list):
        log(f"Processing movie list with {len(movie_data)} items")
        for movie in movie_data:
            title = movie.get('title') or movie.get('name') or 'Unknown Movie'
            thumbnail = movie.get('thumbnail') or movie.get('thumb') or movie.get('poster') or ADDON_ICON
            fanart = movie.get('fanart') or movie.get('background') or movie.get('backdrop') or ADDON_FANART
            
            # Check for 'urls' array (multiple sources)
            if 'urls' in movie and isinstance(movie['urls'], list) and movie['urls']:
                # Process multiple URLs
                urls = []
                for url in movie['urls']:
                    if url and isinstance(url, str):
                        urls.append(url)
                        log(f"Added URL for {title}: {url}")
                
                if urls:
                    movies.append({
                        'title': title,
                        'thumbnail': thumbnail,
                        'fanart': fanart,
                        'urls': urls
                    })
                    log(f"Added movie {title} with {len(urls)} links")
            # Check for single 'url'
            elif 'url' in movie and movie['url']:
                log(f"Added movie {title} with single URL: {movie['url']}")
                movies.append({
                    'title': title,
                    'thumbnail': thumbnail,
                    'fanart': fanart,
                    'urls': [movie['url']]
                })
            else:
                log(f"Movie {title} has no URL or urls field", xbmc.LOGWARNING)
    
    elif isinstance(movie_data, dict):
        log("Processing movie dictionary")
        # Handle dictionary format with categories
        for key, value in movie_data.items():
            if isinstance(value, list):
                for movie in value:
                    title = movie.get('title') or movie.get('name') or 'Unknown Movie'
                    thumbnail = movie.get('thumbnail') or movie.get('thumb') or movie.get('poster') or ADDON_ICON
                    fanart = movie.get('fanart') or movie.get('background') or movie.get('backdrop') or ADDON_FANART
                    
                    if 'urls' in movie and isinstance(movie['urls'], list) and movie['urls']:
                        urls = [url for url in movie['urls'] if url and isinstance(url, str)]
                        if urls:
                            movies.append({
                                'title': title,
                                'thumbnail': thumbnail,
                                'fanart': fanart,
                                'urls': urls
                            })
                    elif 'url' in movie and movie['url']:
                        movies.append({
                            'title': title,
                            'thumbnail': thumbnail,
                            'fanart': fanart,
                            'urls': [movie['url']]
                        })
    
    log(f"Total movies processed: {len(movies)}")
    cache_movies(movies)
    return movies

def show_vod_list(force_refresh=False):
    movies = get_movies(force_refresh)
    
    if not movies:
        xbmcgui.Dialog().ok('Error', 'No VOD content found. Please check your internet connection and try again.')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    log(f"Displaying {len(movies)} movies in VOD list")
    
    for movie in movies:
        title = movie.get('title', 'Unknown Movie')
        urls = movie.get('urls', [])
        thumbnail = movie.get('thumbnail', ADDON_ICON)
        fanart = movie.get('fanart', ADDON_FANART)
        
        # Display title without any source indicators
        display_title = title
        
        li = xbmcgui.ListItem(label=display_title)
        
        art = {
            'thumb': extract_artwork_url(thumbnail, 'thumb'),
            'icon': extract_artwork_url(thumbnail, 'thumb'),
            'fanart': extract_artwork_url(fanart, 'fanart'),
            'poster': extract_artwork_url(thumbnail, 'thumb')
        }
        li.setArt(art)
        
        # Set plot info showing available links (without "Unknown" text)
        if len(urls) > 1:
            source_list = []
            for idx, url in enumerate(urls[:5]):
                url_lower = url.lower()
                quality = "Link"
                if '1080' in url_lower or '1080p' in url_lower:
                    quality = "1080p"
                elif '720' in url_lower or '720p' in url_lower:
                    quality = "720p"
                elif '4k' in url_lower or '2160' in url_lower:
                    quality = "4K"
                elif '480' in url_lower or '480p' in url_lower:
                    quality = "480p"
                source_list.append(f"• {quality}")
            if len(urls) > 5:
                source_list.append(f"• ... and {len(urls) - 5} more")
            plot = f"Click to select from {len(urls)} available links\n\nAvailable Links:\n" + "\n".join(source_list)
        else:
            plot = f"Click to play: {title}"
        
        li.setInfo('video', {
            'title': title,
            'plot': plot,
            'mediatype': 'movie'
        })
        li.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(
            HANDLE,
            get_url(action='play_movie_with_selector', movie_data=urllib.parse.quote(json.dumps({
                'title': title,
                'thumbnail': thumbnail,
                'fanart': fanart,
                'urls': urls
            }))),
            li,
            isFolder=False
        )
    
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

# ============ FAVOURITES FUNCTIONS (TV Channels Only) ============

def save_custom_favourite(ct, cu, sn, thumb=ADDON_ICON, fanart=ADDON_FANART, movie_data=None):
    """Save TV channels to favourites only - movies are not stored"""
    ensure_cache_dir()
    f = load_custom_favourites()
    fid = f"{sn}_{ct}_{int(time.time())}"
    
    # Only allow TV channels to be saved as favourites
    if sn == "Movies":
        log(f"Movies cannot be added to favourites - ignoring request for {ct}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Info', 'Movies cannot be added to favourites.\nOnly TV channels can be saved.')
        return False
    
    # TV Channel handling
    cid = extract_channel_id_from_url(cu)
    tok = extract_token_from_url(cu)
    if tok and cid:
        cache_token(cid, tok)
    f[fid] = {
        'title': ct,
        'encrypted_url': encrypt_favourite_url(cu),
        'source': sn,
        'channel_id': cid,
        'is_movie': False,
        'thumbnail': ADDON_ICON,
        'fanart': ADDON_FANART,
        'timestamp': time.time(),
        'last_updated': time.time()
    }
    
    try:
        with open(FAVOURITES_FILE, 'w') as fh:
            json.dump(f, fh)
        xbmcgui.Dialog().notification('Favourite Added', f'Added {ct} to favourites', ADDON_ICON, 3000)
        return True
    except Exception as e:
        log(f"Error saving favourite: {str(e)}", xbmc.LOGERROR)
        return False

def load_custom_favourites():
    if not xbmcvfs.exists(FAVOURITES_FILE): 
        return {}
    try:
        with open(FAVOURITES_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        log(f"Error loading favourites: {str(e)}", xbmc.LOGERROR)
        return {}

def remove_custom_favourite(fid):
    f = load_custom_favourites()
    if fid in f:
        del f[fid]
    try:
        with open(FAVOURITES_FILE, 'w') as fh:
            json.dump(f, fh)
        xbmcgui.Dialog().notification('Favourite Removed', 'Favourite removed successfully', ADDON_ICON, 3000)
        return True
    except Exception as e:
        log(f"Error removing favourite: {str(e)}", xbmc.LOGERROR)
        return False

def update_favourite_urls():
    """Update favourite URLs - can be called manually or automatically"""
    f = load_custom_favourites()
    uc = 0
    for fid, fav in f.items():
        # Skip if it's a movie (shouldn't exist, but just in case)
        if fav.get('is_movie', False):
            continue
            
        sn = fav.get('source')
        ct = fav.get('title')
        cid = fav.get('channel_id')
        
        if not sn or not ct:
            continue
            
        cc = get_channels_from_source(sn, False)
        if cc is None:
            continue
        mc = None
        for ch in cc:
            if ch.get('title') == ct:
                mc = ch
                break
                
        if mc and mc.get('url'):
            nu = mc['url']
            ce = fav.get('encrypted_url')
            cd = decrypt_favourite_url(ce) if ce else None
            if nu != cd:
                if cid:
                    nt = extract_token_from_url(nu)
                    if nt:
                        cache_token(cid, nt)
                f[fid]['encrypted_url'] = encrypt_favourite_url(nu)
                f[fid]['last_updated'] = time.time()
                uc += 1
                
    if uc > 0:
        try:
            with open(FAVOURITES_FILE, 'w') as fh:
                json.dump(f, fh)
        except Exception as e:
            log(f"Error updating favourites: {str(e)}", xbmc.LOGERROR)
    return uc

def get_smart_favourite_url(fav):
    # Only for TV channels
    eu = fav.get('encrypted_url')
    if eu:
        du = decrypt_favourite_url(eu)
        if du:
            cid = fav.get('channel_id')
            if cid:
                ct = get_cached_token(cid)
                if ct:
                    p = urllib.parse.urlparse(du)
                    q = urllib.parse.parse_qs(p.query)
                    q['X-Plex-Token'] = ct
                    du = urllib.parse.urlunparse((p.scheme, p.netloc, p.path, p.params, urllib.parse.urlencode(q, doseq=True), p.fragment))
            return du
    return None

def show_custom_favourites(force_refresh=False):
    """Show favourites - opens instantly without automatic updates"""
    # Load favourites directly without updating
    f = load_custom_favourites()
    
    # Filter out any movie favourites that might exist (for backward compatibility)
    f = {fid: fav for fid, fav in f.items() if not fav.get('is_movie', False)}
    
    if not f:
        xbmcgui.Dialog().ok('No Favourites', 'You haven\'t added any TV channel favourites yet.\n\nNote: Movies cannot be added to favourites.')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    # Add "Refresh Streams" option at the top
    refresh_li = xbmcgui.ListItem(label="[COLOR yellow]Refresh All Favourites[/COLOR]")
    refresh_li.setArt({'thumb': ADDON_ICON, 'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    refresh_li.setInfo('video', {
        'title': 'Refresh All Favourites',
        'plot': 'Manually check for updates to all favourite channel URLs'
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='refresh_favourites'), refresh_li, isFolder=False)
    
    # Now show all favourites
    for fid, fav in f.items():
        t = fav.get('title', 'Unknown')
        s = fav.get('source', 'Unknown Source')
        lu = fav.get('last_updated', 0)
        cu = get_smart_favourite_url(fav)
        
        if not cu:
            t = f"[COLOR red]{t} (Broken)"
        
        li = xbmcgui.ListItem(label=t)
        li.setArt({
            'thumb': fav.get('thumbnail', ADDON_ICON),
            'icon': fav.get('thumbnail', ADDON_ICON),
            'fanart': fav.get('fanart', ADDON_FANART)
        })
        
        pl = f'Channel: {t}\nSource: {s}\nLast Updated: {time.strftime("%Y-%m-%d %H:%M", time.localtime(lu))}'
        li.setInfo('video', {'title': t, 'plot': pl, 'genre': 'Channel Favourite'})
            
        if cu:
            li.setProperty('IsPlayable', 'true')
            
        li.addContextMenuItems([
            ('Remove Favourite', f'RunPlugin({get_url(action="remove_favourite", fav_id=fid)})'),
            ('Update This Favourite', f'RunPlugin({get_url(action="update_single_favourite", fav_id=fid)})'),
            ('Refresh Token', f'RunPlugin({get_url(action="refresh_token", fav_id=fid)})')
        ])
        
        play_url = get_url(action='play_favourite', encrypted_url=fav.get('encrypted_url')) if cu else get_url(action='noop')
            
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
        
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def update_single_favourite(fid):
    f = load_custom_favourites()
    if fid not in f:
        return False
        
    fav = f[fid]
    
    # Skip movie favourites
    if fav.get('is_movie', False):
        xbmcgui.Dialog().ok('Information', 'Movies cannot be updated as favourites.')
        return False
        
    sn = fav.get('source')
    ct = fav.get('title')
    cid = fav.get('channel_id')
    
    cc = get_channels_from_source(sn, True)
    if cc is None:
        xbmcgui.Dialog().ok('Error', f'Could not find source {sn}')
        return False
    mc = None
    for ch in cc:
        if ch.get('title') == ct:
            mc = ch
            break
            
    if mc and mc.get('url'):
        nu = mc['url']
        if cid:
            nt = extract_token_from_url(nu)
            if nt:
                cache_token(cid, nt)
        f[fid]['encrypted_url'] = encrypt_favourite_url(nu)
        f[fid]['last_updated'] = time.time()
        try:
            with open(FAVOURITES_FILE, 'w') as fh:
                json.dump(f, fh)
            xbmcgui.Dialog().notification('Favourite Updated', f'Updated {ct}', ADDON_ICON, 3000)
            return True
        except Exception as e:
            log(f"Error updating single favourite: {str(e)}", xbmc.LOGERROR)
    else:
        xbmcgui.Dialog().ok('Error', f'Could not find updated URL for {ct}')
    return False

def refresh_all_favourites():
    """Manually refresh all favourites and show updated list"""
    xbmcgui.Dialog().notification('Refreshing', 'Updating all favourite channels...', ADDON_ICON, 2000)
    updated = update_favourite_urls()
    if updated > 0:
        xbmcgui.Dialog().notification('Refresh Complete', f'Updated {updated} favourite channel(s)', ADDON_ICON, 3000)
    else:
        xbmcgui.Dialog().notification('Refresh Complete', 'All favourites are up to date', ADDON_ICON, 3000)
    show_custom_favourites()

def refresh_token_for_favourite(fid):
    f = load_custom_favourites()
    if fid not in f:
        return False
        
    if f[fid].get('is_movie', False):
        xbmcgui.Dialog().ok('Information', 'Movies do not require tokens.')
        return False
        
    cid = f[fid].get('channel_id')
    if cid:
        tc = load_token_cache()
        if cid in tc:
            del tc[cid]
            save_token_cache(tc)
        xbmcgui.Dialog().notification('Token Refreshed', 'Token will be refreshed on next play', ADDON_ICON, 3000)
        return True
    return False

def play_encrypted_favourite(eu):
    du = decrypt_favourite_url(eu)
    if du:
        # Check circuit breaker before playing
        if circuit_breaker.check_url(du):
            return play_channel(du)
        else:
            xbmcgui.Dialog().ok('Stream Unavailable', 'This stream has had multiple failures. Please try again later.')
            return False
    else:
        xbmcgui.Dialog().ok('Error', 'Could not decrypt favourite URL. It may be corrupted.')
        return False

# ============ TV CHANNEL FUNCTIONS ============

# ENHANCED: Stream type detection with more platforms
def detect_stream_type(url):
    u = url.lower()
    
    # Check for various streaming protocols
    if 'plex.tv' in u:
        if '.m3u8' in u:
            return ('hls', 'plex')
        elif '.mpd' in u:
            return ('dash', 'plex')
        else:
            return ('hls', 'plex')  # Default Plex to HLS
    
    # Check for specific CDN patterns
    if 'cloudfront.net' in u or 'cloudflare.com' in u:
        if '.m3u8' in u:
            return ('hls', 'cdn')
        elif '.mpd' in u:
            return ('dash', 'cdn')
    
    # Check for known streaming services
    if 'akamaized.net' in u:
        return ('hls', 'akamai')
    
    # Check for specific platforms
    if 'a1xs.vip' in u:
        return ('hls', 'a1xs')
    if 'jmp2.uk' in u:
        return ('hls', 'jmp2')
    
    # Generic detection
    if '.m3u8' in u or 'm3u8' in u:
        return ('hls', 'generic')
    elif '.mpd' in u:
        return ('dash', 'generic')
    elif '.mp4' in u:
        return ('mp4', 'generic')
    elif '.ts' in u:
        return ('ts', 'generic')
    
    return ('http', 'generic')

# ENHANCED: Setup legacy stream with better fallback
def setup_legacy_stream(li, url):
    """Fallback for when inputstream helper is not available"""
    headers = get_stream_headers(url)
    header_string = '&'.join([f'{k}={urllib.parse.quote(str(v))}' for k, v in headers.items()])
    
    li.setMimeType('video/unknown')
    li.setProperty('IsPlayable', 'true')
    
    # Try to guess mime type from URL
    url_lower = url.lower()
    if url_lower.endswith('.m3u8') or 'm3u8' in url_lower:
        li.setMimeType('application/vnd.apple.mpegurl')
    elif url_lower.endswith('.mpd'):
        li.setMimeType('application/dash+xml')
    elif url_lower.endswith('.mp4'):
        li.setMimeType('video/mp4')
    elif url_lower.endswith('.ts'):
        li.setMimeType('video/mp2t')
    
    if header_string:
        li.setPath(f"{url}|{header_string}")
    else:
        li.setPath(url)
    
    li.setContentLookup(False)
    return True

# ENHANCED: Setup TS stream with proper headers
def setup_ts_stream(li, url, header_string):
    """Setup TS stream with proper headers"""
    li.setProperty('inputstream', '')
    li.setProperty('inputstream.adaptive', '')
    li.setMimeType('video/mp2t')
    li.setContentLookup(False)
    
    if header_string:
        li.setPath(f"{url}|{header_string}")
    else:
        li.setPath(url)
    
    return True

# ENHANCED: Inputstream setup with user-configurable settings
def setup_inputstream(li, url, stream_type='hls', platform='generic'):
    """Enhanced inputstream setup with user-configurable settings"""
    if not HAS_INPUTSTREAM_HELPER:
        return setup_legacy_stream(li, url)
    
    # Load user settings
    settings = load_stream_settings()
    
    headers = get_stream_headers(url)
    header_string = '&'.join([f'{k}={urllib.parse.quote(str(v))}' for k, v in headers.items()])
    
    # Special handling for different stream types
    if stream_type == 'ts':
        return setup_ts_stream(li, url, header_string)
    
    # Standard inputstream adaptive setup with enhanced properties
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.stream_headers', header_string)
    
    # Common properties for all adaptive streams - using user settings
    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
    li.setProperty('inputstream.adaptive.manifest_retry_attempts', settings.get('manifest_retry_attempts', '5'))
    li.setProperty('inputstream.adaptive.manifest_retry_delay', settings.get('manifest_retry_delay', '2000'))
    li.setProperty('inputstream.adaptive.timeout', settings.get('timeout', '30'))
    
    # HLS specific enhancements with user settings
    if stream_type == 'hls':
        ih = inputstreamhelper.Helper('hls')
        if ih.check_inputstream():
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            # Enhanced HLS settings - all user configurable
            li.setProperty('inputstream.adaptive.live_delay', settings.get('live_delay', '10'))
            li.setProperty('inputstream.adaptive.live_seekable', settings.get('live_seekable', 'true'))
            li.setProperty('inputstream.adaptive.live_playlist_retry_attempts', 
                          settings.get('live_playlist_retry_attempts', '10'))
            li.setProperty('inputstream.adaptive.live_playlist_retry_delay', 
                          settings.get('live_playlist_retry_delay', '3000'))
            li.setProperty('inputstream.adaptive.live_playlist_readahead', 
                          settings.get('live_playlist_readahead', '5'))
            
            # Force manual bandwidth control by setting bandwidth_factor to exactly 1.0
            # This effectively disables auto-bandwidth detection
            li.setProperty('inputstream.adaptive.bandwidth_factor', '1.0')
            li.setProperty('inputstream.adaptive.max_bandwidth', settings.get('max_bandwidth', '10000000'))
            li.setProperty('inputstream.adaptive.media_bandwidth', settings.get('media_bandwidth', '5000000'))
            
            # Platform specific settings
            if platform == 'plex':
                li.setProperty('inputstream.adaptive.manifest_headers', header_string)
                li.setProperty('inputstream.adaptive.license_flags', 'persistent_storage')
                li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                li.setProperty('inputstream.adaptive.adaptive_debug', settings.get('adaptive_debug', 'false'))
            elif platform == 'cdn':
                li.setProperty('inputstream.adaptive.manifest_headers', header_string)
                li.setProperty('inputstream.adaptive.connection_retry', settings.get('connection_retry', '5'))
                li.setProperty('inputstream.adaptive.session_reconnect', settings.get('session_reconnect', 'true'))
            elif platform == 'akamai':
                li.setProperty('inputstream.adaptive.manifest_headers', header_string)
                li.setProperty('inputstream.adaptive.connection_retry', settings.get('connection_retry', '3'))
                li.setProperty('inputstream.adaptive.connection_timeout', settings.get('timeout', '15'))
            
            li.setContentLookup(False)
            return True
            
    # DASH specific enhancements with user settings
    elif stream_type == 'dash':
        ih = inputstreamhelper.Helper('mpd')
        if ih.check_inputstream():
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # Enhanced DASH settings - force manual bandwidth
            li.setProperty('inputstream.adaptive.mpd_retry_attempts', settings.get('manifest_retry_attempts', '5'))
            li.setProperty('inputstream.adaptive.mpd_retry_delay', settings.get('manifest_retry_delay', '2000'))
            li.setProperty('inputstream.adaptive.timeout', settings.get('timeout', '30'))
            li.setProperty('inputstream.adaptive.bandwidth_factor', '1.0')
            
            if platform == 'plex':
                li.setProperty('inputstream.adaptive.license_flags', 'persistent_storage')
                li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            
            return True
    
    # MP4 specific setup
    elif stream_type == 'mp4':
        li.setMimeType('video/mp4')
        li.setContentLookup(False)
        if header_string:
            li.setPath(f"{url}|{header_string}")
        else:
            li.setPath(url)
        return True
    
    return False

# ENHANCED: Channel playback with circuit breaker and better error handling
def play_channel(url):
    """Enhanced channel playback with fallback mechanisms"""
    try:
        log(f"Starting playback for: {url[:100]}...")
        
        # Check circuit breaker
        if not circuit_breaker.check_url(url):
            xbmcgui.Dialog().ok('Stream Unavailable', 
                'This stream has had multiple failures and is temporarily blocked.\nPlease try again later or refresh the token.')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return False
        
        # Validate URL
        if not url or not url.startswith(('http://', 'https://')):
            log(f"Invalid URL: {url}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', 'Invalid stream URL')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return False
        
        # Detect stream type and platform
        stream_type, platform = detect_stream_type(url)
        log(f"Detected stream: {stream_type} on {platform}")
        
        # Extract and refresh token if Plex
        if platform == 'plex':
            channel_id = extract_channel_id_from_url(url)
            if channel_id:
                token = get_cached_token(channel_id)
                if token:
                    # Update URL with new token
                    parsed = urllib.parse.urlparse(url)
                    query = urllib.parse.parse_qs(parsed.query)
                    query['X-Plex-Token'] = token
                    url = urllib.parse.urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, urllib.parse.urlencode(query, doseq=True),
                        parsed.fragment
                    ))
                    log(f"Updated URL with cached token")
                else:
                    log(f"No cached token found for channel {channel_id}")
        
        # Create list item with proper settings
        li = xbmcgui.ListItem(path=url)
        li.setProperty('IsPlayable', 'true')
        
        # Set proper mime type based on stream
        mime_types = {
            'hls': 'application/vnd.apple.mpegurl',
            'dash': 'application/dash+xml',
            'ts': 'video/mp2t',
            'mp4': 'video/mp4',
            'http': 'video/unknown'
        }
        li.setMimeType(mime_types.get(stream_type, 'video/unknown'))
        li.setContentLookup(False)
        
        # Setup inputstream with enhanced settings
        if not setup_inputstream(li, url, stream_type, platform):
            log("Failed to setup inputstream, using fallback", xbmc.LOGWARNING)
            setup_legacy_stream(li, url)
        
        # Add additional properties for stability
        li.setProperty('inputstream.adaptive.license_key', '')
        li.setProperty('inputstream.adaptive.license_url', '')
        li.setProperty('inputstream.adaptive.decrypt_bin', '')
        
        # Force manual bandwidth control - set specific bandwidth values
        li.setProperty('inputstream.adaptive.media_bandwidth', '5000000')
        li.setProperty('inputstream.adaptive.min_bandwidth', '1000000')
        li.setProperty('inputstream.adaptive.max_bandwidth', '15000000')
        li.setProperty('inputstream.adaptive.bandwidth_factor', '1.0')
        
        # Disable thumbnails for live streams
        li.setArt({
            'thumb': ADDON_ICON,
            'icon': ADDON_ICON,
            'fanart': ADDON_FANART
        })
        
        # Resolve URL and start playback
        log("Starting playback")
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        
        # Reset circuit breaker on successful play
        # (We can't know if it succeeded, but we'll assume it did)
        # Circuit breaker will only trip on explicit failures
        
        return True
        
    except Exception as e:
        log(f"Critical playback error: {str(e)}", xbmc.LOGERROR)
        
        # Record failure in circuit breaker
        circuit_breaker.record_failure(url)
        
        # Show user-friendly error message
        error_msg = str(e)
        if "401" in error_msg or "403" in error_msg:
            dialog_msg = "Stream requires authentication or has expired.\nTry refreshing the token."
        elif "404" in error_msg:
            dialog_msg = "Stream not found. It may have been removed."
        elif "timeout" in error_msg.lower():
            dialog_msg = "Connection timeout. Please try again later."
        elif "SSL" in error_msg or "certificate" in error_msg:
            dialog_msg = "SSL certificate error. Your system time may be incorrect."
        else:
            dialog_msg = f"Playback error: {error_msg[:100]}"
        
        xbmcgui.Dialog().ok('Playback Error', dialog_msg)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False

def play_encrypted_channel(encrypted_url):
    du=decrypt_favourite_url(encrypted_url)
    if du: 
        return play_channel(du)
    else: 
        xbmcgui.Dialog().ok('Error','Could not decrypt stream URL.')
        return False

def refresh_channel_token(cid):
    tc=load_token_cache()
    if cid in tc: 
        del tc[cid]
        save_token_cache(tc)
        # Also clear circuit breaker for this channel
        # We don't have the URL, but we can clear all circuit breaker entries
        # This is a simple approach - could be enhanced
        log(f"Refreshed token for channel {cid}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification('Token Refreshed','Channel token will be refreshed',ADDON_ICON,3000)
    return True

def list_source_channels(sn,fr=False):
    if sn == "Movies":
        show_vod_list(fr)
        return
    
    ch=get_channels_from_source(sn,fr)
    if not ch: 
        xbmcgui.Dialog().ok('Error',f'No channels found from {sn}. Please check your internet connection and try again.')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    ch.sort(key=lambda x: x['title'].lower())
    for c in ch:
        t=c.get('title','Unknown Channel')
        u=c.get('url','')
        cid=c.get('channel_id','')
        th=c.get('thumbnail',ADDON_ICON)
        li=xbmcgui.ListItem(label=t)
        li.setArt({'thumb':th,'icon':th,'fanart':ADDON_FANART})
        st,pf=detect_stream_type(u)
        li.setInfo('video',{'title':t,'plot':f'Live TV Channel: {t}\nSource: {sn}\nStream Type: {st.upper()}'})
        li.setProperty('IsPlayable','true')
        cm=[('Add To My Favourites',f'RunPlugin({get_url(action="add_favourite",title=urllib.parse.quote(t),url=urllib.parse.quote(u),source=sn)})')]
        if pf=='plex' and cid: 
            cm.append(('Refresh Token',f'RunPlugin({get_url(action="refresh_channel_token",channel_id=cid)})'))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(HANDLE,get_encrypted_play_url(u),li,isFolder=False)
    xbmcplugin.setContent(HANDLE,'videos')
    xbmcplugin.endOfDirectory(HANDLE)

# ============ MAIN LANDING PAGE ============

def show_landing_page():
    global seen_titles_global
    seen_titles_global=set()
    
    source_names = sorted([name.strip() for name in PLAYLIST_SOURCES.keys()])
    
    for sn in source_names:
        li = xbmcgui.ListItem(label=sn)
        li.setArt({'thumb': ADDON_ICON, 'icon': ADDON_ICON, 'fanart': ADDON_FANART})
        
        if sn == "Movies":
            li.setInfo('video', {'title': sn, 'plot': 'Video on Demand - Movies and content (Cannot be added to favourites)'})
        else:
            li.setInfo('video', {'title': sn, 'plot': f'Browse channels from {sn}'})
        
        xbmcplugin.addDirectoryItem(HANDLE, get_url(action='source', source=sn), li, isFolder=True)
    
    li = xbmcgui.ListItem(label="My Favourites")
    li.setArt({'thumb': ADDON_ICON, 'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    li.setInfo('video', {'title': 'Vortex Favourites', 'plot': 'Your saved favourite TV channels (Movies cannot be favourited)'})
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='show_favourites'), li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Refresh Lists")
    li.setArt({'thumb': ADDON_ICON, 'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    li.setInfo('video', {'title': 'Refresh Playlists And Clear Cache', 'plot': 'Clear playlist and token cache'})
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='clear_cache'), li, isFolder=False)
    
    # Add the Stream Settings option - now just opens inputstream.adaptive
    li = xbmcgui.ListItem(label="Stream Settings")
    li.setArt({'thumb': ADDON_ICON, 'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    li.setInfo('video', {
        'title': 'Stream Settings',
        'plot': 'Open inputstream.adaptive settings to adjust stream performance\n\nNote: Manual bandwidth control is enforced by the addon'
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='open_inputstream'), li, isFolder=False)
    
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)

# ============ ROUTER ============

def router(params):
    a=params.get('action','')
    u=params.get('url','')
    s=params.get('source','')
    fr=params.get('refresh','')=='true'
    fid=params.get('fav_id','')
    eu=params.get('encrypted_url','')
    t=params.get('title','')
    cid=params.get('channel_id','')
    
    thumbnail = params.get('thumbnail', '')
    fanart = params.get('fanart', '')
    movie_data = params.get('movie_data', '')
    
    if a=='play' and u: 
        play_channel(urllib.parse.unquote(u))
    elif a=='play_encrypted' and eu: 
        play_encrypted_channel(eu)
    elif a=='play_favourite' and eu: 
        play_encrypted_favourite(eu)
    elif a=='play_movie' and u: 
        play_movie(urllib.parse.unquote(u), urllib.parse.unquote(t), urllib.parse.unquote(thumbnail), urllib.parse.unquote(fanart))
    elif a=='play_movie_with_selector' and movie_data:
        try:
            movie_data_dict = json.loads(urllib.parse.unquote(movie_data))
            log(f"Playing movie with selector, data: {movie_data_dict}")
            play_movie_with_quality_selector(movie_data_dict, 
                                            movie_data_dict.get('title', 'Unknown'), 
                                            movie_data_dict.get('thumbnail', ADDON_ICON), 
                                            movie_data_dict.get('fanart', ADDON_FANART))
        except Exception as e:
            log(f"Error playing movie with selector: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Could not load movie data: {str(e)}')
    
    elif a=='add_favourite' and u and t: 
        save_custom_favourite(urllib.parse.unquote(t), urllib.parse.unquote(u), s)
    elif a=='remove_favourite' and fid: 
        remove_custom_favourite(fid)
        show_custom_favourites()
    elif a=='update_single_favourite' and fid: 
        update_single_favourite(fid)
        show_custom_favourites()
    elif a=='refresh_token' and fid: 
        refresh_token_for_favourite(fid)
        show_custom_favourites()
    elif a=='show_favourites': 
        show_custom_favourites()
    elif a=='refresh_favourites':
        refresh_all_favourites()
    
    elif a=='source' and s: 
        list_source_channels(s,fr)
    elif a=='refresh_channel_token' and cid: 
        refresh_channel_token(cid)
        xbmc.executebuiltin('Container.Refresh')
    
    elif a=='open_inputstream':
        open_inputstream_settings()
        xbmc.executebuiltin('Container.Refresh')
    
    elif a=='clear_cache':
        if clear_cache(): 
            xbmcgui.Dialog().ok('Information', 'Playlists refreshed and all caches cleared.\n\nYour favourites have been preserved.')
        show_landing_page()
    elif a=='noop': 
        pass
    else: 
        show_landing_page()

if __name__ == '__main__':
    # Load remote config first
    if fetch_remote_config():
        router(dict(urllib.parse.parse_qsl(sys.argv[2][1:])))
    else:
        xbmcgui.Dialog().ok('Configuration Error', 'Failed to load remote configuration.\nPlease check your internet connection and try again.')
        sys.exit()
