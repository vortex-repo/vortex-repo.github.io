import json
import re
from urllib.parse import parse_qs, quote, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

from ..plugin import Plugin


INVIDIOUS_INSTANCES = [
    "https://inv.nadeko.net",
    "https://vid.puffyan.us",
    "https://invidious.fdn.fr",
    "https://inv.tux.pizza",
    "https://invidious.nerdvpn.de",
]
YOUTUBE_ADDON_ID = "plugin.video.youtube"


def extract_video_id(value):
    value = str(value or "")
    if re.fullmatch(r"[^\"&?/\s]{11}", value):
        return value
    match = re.search(r"(?:youtube\.com/(?:watch\?v=|embed/|live/)|youtu\.be/)([^\"&?/\s]{11})", value)
    if match:
        return match.group(1)
    return parse_qs(urlparse(value).query).get("v", [""])[0]


def youtube_plugin_url(value):
    video_id = extract_video_id(value)
    if not re.fullmatch(r"[^\"&?/\s]{11}", video_id):
        return ""
    return "plugin://{}/play/?video_id={}".format(YOUTUBE_ADDON_ID, quote(video_id))


def youtube_addon_available():
    try:
        xbmcaddon.Addon(YOUTUBE_ADDON_ID)
        return True
    except RuntimeError:
        return False


def _missing_youtube_addon(message):
    xbmcgui.Dialog().notification(
        "MicroJen",
        message,
        getattr(xbmcgui, "NOTIFICATION_ERROR", ""),
        5000,
    )


def play_youtube(value):
    plugin_url = youtube_plugin_url(value)
    if not plugin_url:
        return None
    if not youtube_addon_available():
        _missing_youtube_addon("Install the YouTube add-on to play this video.")
        return True
    xbmc.executebuiltin("RunPlugin({})".format(plugin_url))
    return True


def open_youtube_addon():
    if not youtube_addon_available():
        _missing_youtube_addon("Install the YouTube add-on to use YouTube search.")
        return True
    xbmc.executebuiltin("RunPlugin(plugin://{}/)".format(YOUTUBE_ADDON_ID))
    return True


def extract_playlist_id(url):
    url = swap_link(url)
    return parse_qs(urlparse(url).query).get("list", [""])[0]


def _best_thumbnail(video, video_id):
    thumbnails = video.get("videoThumbnails") or []
    for thumbnail in reversed(thumbnails):
        if isinstance(thumbnail, dict) and thumbnail.get("url"):
            return thumbnail["url"]
    return "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(video_id)


def invidious_playlist_items(playlist_id):
    if not playlist_id:
        return []
    for instance in INVIDIOUS_INSTANCES:
        try:
            request = Request(
                "{}/api/v1/playlists/{}".format(instance, playlist_id),
                headers={"User-Agent": "Mozilla/5.0"},
            )
            with urlopen(request, timeout=12) as response:
                data = json.loads(response.read().decode("utf-8", "replace"))
        except Exception:
            continue
        author = data.get("author") or ""
        items = []
        for video in data.get("videos") or []:
            video_id = video.get("videoId") or video.get("id")
            if not video_id:
                continue
            title = video.get("title") or "YouTube Video"
            display_title = "{} - {}".format(author, title) if author else title
            items.append({
                "type": "item",
                "title": display_title,
                "link": "https://www.youtube.com/watch?v={}".format(video_id),
                "thumbnail": _best_thumbnail(video, video_id),
                "summary": display_title,
            })
        if items:
            return items
    return []


class youtube(Plugin):
    name = "youtube"
    priority = 120

    def get_list(self, url):
        if "youtube.com" in url or "plugin.video.youtube" in url:
            return json.dumps({"items": invidious_playlist_items(extract_playlist_id(url))})

    def process_item(self, item):
        if item.get("youtube") == "search":
            item["link"] = "youtube/search"
            item["is_dir"] = True
            item["list_item"] = xbmcgui.ListItem(item.get("title", "YouTube Search"))
            return item
        return None

    def play_video(self, item):
        item = json.loads(item)
        link = item.get("link")
        if isinstance(link, list):
            link = link[0] if link else ""
        return play_youtube(swap_link(link))

    def routes(self, plugin):
        @plugin.route("/youtube/search")
        def search():
            open_youtube_addon()

        @plugin.route("/youtube/play/<path:yt_id>")
        def play(yt_id):
            play_youtube(yt_id)


def swap_link(link):
    link = str(link or "").rstrip("/")
    if "youtube.com/playlist_list=" in link:
        return link.replace("playlist_list", "playlist?list")
    if "plugin.video.youtube/playlist" in link:
        return "https://www.youtube.com/playlist?list={}".format(link.split("/")[-1])
    if "plugin.video.youtube/channel" in link:
        channel_id = link.split("/")[-1]
        return "https://www.youtube.com/{}{}".format("" if channel_id.startswith("@") else "channel/", channel_id)
    if "plugin.video.youtube/watch" in link:
        return "https://www.youtube.com/watch?v={}".format(link.split("=")[-1])
    return link
